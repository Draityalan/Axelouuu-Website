Auteur : Axel Juino
nom : tailleFenetre


FR : -------------------------------------------------

Modifie la taille d'une fenêtre
Pour utiliser ce fichier :
      call tailleFenetre.bat nombreDeColones nombreDeLignes

--------------------------------------------------------



ENG : -------------------------------------------------

Change window size
For use the file :
      call tailleFenetre.bat numberOfColums numberOfLines

--------------------------------------------------------