Auteur : Axel Juino
nom : cadre

FR : -----------------------------------------

Créer un cadre autour de plusieurs mots
Pour utiliser ce fichier :
      call cadre.bat mot1 mot2 mot3
Max : 9 mots

-----------------------------------------------



ENG : ----------------------------------------

Create a frame around several words
For use the file :
      call cadre.bat mot1 mot2 mot3
Max : 9 mots

-----------------------------------------------